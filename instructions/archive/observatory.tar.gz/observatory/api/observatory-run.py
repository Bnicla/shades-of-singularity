"""
Vercel Cron Function: runs the observatory pipeline daily.

Triggered by Vercel's cron scheduler (configured in vercel.json).
Executes the full ingest -> dedup -> triage -> adjudicate -> render cycle,
then stores the rendered HTML in Vercel KV for serving.

Schedule: 0 10 * * * (6 AM ET / 10 AM UTC daily)

Environment variables required:
  ANTHROPIC_API_KEY
  KV_REST_API_URL
  KV_REST_API_TOKEN
  CRON_SECRET (optional, for Vercel cron auth)
"""

import json
import logging
import os
import sys
from http.server import BaseHTTPRequestHandler

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "observatory", "src"))

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("observatory.cron")


class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        # Verify cron secret if configured
        cron_secret = os.environ.get("CRON_SECRET")
        if cron_secret:
            auth = self.headers.get("Authorization", "")
            if auth != f"Bearer {cron_secret}":
                self.send_response(401)
                self.end_headers()
                self.wfile.write(b'{"error": "unauthorized"}')
                return

        try:
            from pipeline import run_pipeline
            run_pipeline(mode="production")

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({
                "status": "success",
                "message": "Pipeline executed successfully"
            }).encode())

        except Exception as e:
            logger.error(f"Pipeline failed: {e}", exc_info=True)
            self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({
                "status": "error",
                "message": str(e)
            }).encode())

    def log_message(self, format, *args):
        logger.info(format % args)
