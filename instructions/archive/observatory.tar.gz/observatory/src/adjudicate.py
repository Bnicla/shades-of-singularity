"""
Adjudicator: Sonnet-class evaluation of whether an item bears on
a specific load-bearing claim in the essay collection.

This is the expensive pass. Each item gets a full-text analysis
against the claim inventory defined in prompts.py.
"""

import json
import logging
import time
from typing import Optional

import anthropic

from prompts import ADJUDICATION_SYSTEM, ADJUDICATION_USER

logger = logging.getLogger("observatory.adjudicate")

# Cost control
MAX_ADJUDICATE_BATCH = 50
RATE_LIMIT_DELAY = 1.0  # seconds between API calls


class Adjudicator:
    def __init__(self, api_key: str, model: str = "claude-sonnet-4-20250514"):
        self.client = anthropic.Anthropic(api_key=api_key)
        self.model = model

    def evaluate(self, items: list[dict]) -> list[dict]:
        """Evaluate items against the claim inventory."""
        if len(items) > MAX_ADJUDICATE_BATCH:
            logger.warning(
                f"Adjudication batch size {len(items)} exceeds limit {MAX_ADJUDICATE_BATCH}. "
                f"Processing first {MAX_ADJUDICATE_BATCH} only."
            )
            items = items[:MAX_ADJUDICATE_BATCH]

        results = []
        for i, item in enumerate(items):
            logger.info(f"  Adjudicating {i+1}/{len(items)}: {item.get('title', '')[:60]}...")
            result = self._adjudicate_single(item)
            if result:
                # Merge item metadata into result for rendering
                result["item"] = {
                    "title": item.get("title", ""),
                    "source": item.get("source", ""),
                    "authors": item.get("authors", []),
                    "date": item.get("date", ""),
                    "url": item.get("url", ""),
                    "tier": item.get("tier", 0),
                    "named_scholar": item.get("named_scholar"),
                }
                result["fingerprint"] = item.get("fingerprint", "")
                results.append(result)

            # Rate limiting
            if i < len(items) - 1:
                time.sleep(RATE_LIMIT_DELAY)

        return results

    def _adjudicate_single(self, item: dict) -> Optional[dict]:
        """Run adjudication on a single item."""
        # Use full text if available, fall back to abstract
        text = item.get("text", "") or item.get("abstract", "")

        # Truncate very long texts to manage token costs
        words = text.split()
        if len(words) > 3000:
            text = " ".join(words[:3000]) + "\n\n[... truncated for evaluation ...]"

        user_prompt = ADJUDICATION_USER.format(
            title=item.get("title", ""),
            source=item.get("source", ""),
            authors=", ".join(item.get("authors", [])),
            date=item.get("date", ""),
            url=item.get("url", ""),
            text=text
        )

        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=800,
                system=ADJUDICATION_SYSTEM,
                messages=[{"role": "user", "content": user_prompt}]
            )

            response_text = response.content[0].text.strip()

            # Handle markdown code fences
            if response_text.startswith("```"):
                response_text = response_text.split("\n", 1)[1] if "\n" in response_text else response_text[3:]
                if response_text.endswith("```"):
                    response_text = response_text[:-3]
                response_text = response_text.strip()

            result = json.loads(response_text)

            # Validate required fields
            required = ["clears_bar", "confidence", "primary_claim", "relationship", "summary"]
            for field in required:
                if field not in result:
                    result[field] = None

            return result

        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse adjudication for '{item.get('title', '')}': {e}")
            return {
                "clears_bar": False,
                "confidence": "low",
                "primary_claim": None,
                "secondary_claims": [],
                "relationship": None,
                "summary": f"Parse error during adjudication: {e}",
                "citation_quality": "unknown",
                "named_scholar_match": item.get("tier") == 1,
                "integration_note": None
            }
        except anthropic.RateLimitError:
            logger.warning("Rate limited. Waiting 60s before retry.")
            time.sleep(60)
            return self._adjudicate_single(item)  # Retry once
        except Exception as e:
            logger.error(f"Adjudication API error for '{item.get('title', '')}': {e}")
            return {
                "clears_bar": False,
                "confidence": "low",
                "primary_claim": None,
                "secondary_claims": [],
                "relationship": None,
                "summary": f"API error: {e}",
                "citation_quality": "unknown",
                "named_scholar_match": item.get("tier") == 1,
                "integration_note": None
            }
