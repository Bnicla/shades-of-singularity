"""
Triage filter: cheap Haiku-class pass to determine if an item
plausibly touches one of the six essay axes.

Generous filter. False positives are acceptable; false negatives are not.
"""

import json
import logging
from typing import Optional

import anthropic

from prompts import TRIAGE_SYSTEM, TRIAGE_USER

logger = logging.getLogger("observatory.triage")

# Cost control: maximum items to triage per run
MAX_TRIAGE_BATCH = 200


class TriageFilter:
    def __init__(self, api_key: str, model: str = "claude-haiku-4-5-20251001"):
        self.client = anthropic.Anthropic(api_key=api_key)
        self.model = model

    def filter(self, items: list[dict]) -> list[dict]:
        """Filter items, returning those that pass triage."""
        if len(items) > MAX_TRIAGE_BATCH:
            logger.warning(
                f"Triage batch size {len(items)} exceeds limit {MAX_TRIAGE_BATCH}. "
                f"Processing first {MAX_TRIAGE_BATCH} only."
            )
            items = items[:MAX_TRIAGE_BATCH]

        passed = []
        for item in items:
            result = self._triage_single(item)
            if result and result.get("pass"):
                item["triage_axes"] = result.get("candidate_axes", [])
                item["triage_confidence"] = result.get("confidence", "low")
                passed.append(item)

        return passed

    def _triage_single(self, item: dict) -> Optional[dict]:
        """Run triage on a single item."""
        user_prompt = TRIAGE_USER.format(
            title=item.get("title", ""),
            source=item.get("source", ""),
            date=item.get("date", ""),
            abstract=item.get("abstract", "")[:1000]  # Limit input size
        )

        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=300,
                system=TRIAGE_SYSTEM,
                messages=[{"role": "user", "content": user_prompt}]
            )

            text = response.content[0].text.strip()

            # Handle potential markdown code fences
            if text.startswith("```"):
                text = text.split("\n", 1)[1] if "\n" in text else text[3:]
                if text.endswith("```"):
                    text = text[:-3]
                text = text.strip()

            return json.loads(text)

        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse triage response for '{item.get('title', '')}': {e}")
            # On parse failure, pass the item through (generous filter)
            return {"pass": True, "candidate_axes": ["UNKNOWN"], "confidence": "low"}
        except Exception as e:
            logger.error(f"Triage API error for '{item.get('title', '')}': {e}")
            # On API error, pass the item through
            return {"pass": True, "candidate_axes": ["UNKNOWN"], "confidence": "low"}
